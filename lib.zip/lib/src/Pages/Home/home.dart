import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rent_hive_app/src/Components/HomePage/CarouselSlider.dart';
import 'package:rent_hive_app/src/Components/HomePage/CategorySection.dart';
import 'package:rent_hive_app/src/Components/HomePage/PopularProducts.dart';
import 'package:rent_hive_app/src/Components/HomePage/SearchComponent.dart';

// void main() {
//   runApp(const RentHiveApp());
// }

// class RentHiveApp extends StatelessWidget {
//   const RentHiveApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(textTheme: GoogleFonts.latoTextTheme()),
//       home: const RentHiveHomePage(),
//     );
//   }
// }

class RentHiveHomePage extends StatefulWidget {
  const RentHiveHomePage({super.key});

  @override
  _RentHiveHomePageState createState() => _RentHiveHomePageState();
}

class _RentHiveHomePageState extends State<RentHiveHomePage> {
  int selectedOption = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search bar and filter icon
              Searchbar(),
              const SizedBox(height: 20),

              // Carousel slider
              Carouselslider(),

              const SizedBox(height: 20),

              Categorysection(),

              const SizedBox(height: 20),

              // Popular Places header
              const Text(
                "Popular Products",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 10),

              // List of popular places
              Popularproducts(),
            ],
          ),
        ),
      ),
    );
  }
}
