import 'package:flutter/material.dart';

class Popularproducts extends StatelessWidget {
  final List<String> boxPrices = [
    "1250",
    "1000",
    "890",
    "750",
    "640",
    "580",
    "990",
    "550",
  ];
  final List<String> popularTitles = [
    "Minimal Family House",
    "Modern Home",
    "Classic Studio",
    "Luxury Flat",
    "Budget Room",
    "Elegant Villa",
  ];
  final List<String> popularPrices = [
    "860",
    "1020",
    "790",
    "1200",
    "650",
    "980",
  ];

  List<String> images = [
    'assets/furniture.jpg',
    'assets/property.jpg',
    'assets/vehicle.jpg',
    'assets/electronic.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      itemCount: popularTitles.length,
      itemBuilder: (context, index) {
        return TweenAnimationBuilder(
          tween: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero),
          duration: Duration(milliseconds: 300 + index * 100),
          builder: (context, offset, child) {
            return Transform.translate(
              offset: offset,
              child: GestureDetector(
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("${popularTitles[index]} tapped")),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(color: Colors.grey.shade300, blurRadius: 6),
                    ],
                  ),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(
                          index % 2 == 0 ? 12 : 45,
                        ),
                        child: Image.asset(
                          'assets/image${(index % 5) + 1}.jpg',
                          width: 90,
                          height: 90,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              popularTitles[index],
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              "3200 sq.ft | 6BHK\nDhaka, Bangladesh",
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        "\$${popularPrices[index]}",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.green[800],
                          fontSize: 16,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
