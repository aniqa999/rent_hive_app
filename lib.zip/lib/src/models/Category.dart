import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Category {
  final String label;
  final IconData icon;

  Category({required this.label, required this.icon});
}
