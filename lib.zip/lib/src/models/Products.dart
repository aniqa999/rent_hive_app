class Product {
  final String imageURL;
  final double price;
  final String title;
  final String description;

  Product({
    required this.imageURL,
    required this.price,
    required this.title,
    required this.description,
  });
}
