import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import './src/Pages/Welcome/WelcomeScreen.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'Rent Hive',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        primaryColor: Colors.white,
        scaffoldBackgroundColor: Colors.grey[50],
        textTheme: GoogleFonts.latoTextTheme(),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.white,
          selectedItemColor: Colors.deepPurple,
          unselectedItemColor: Colors.grey,
          type: BottomNavigationBarType.fixed,
          elevation: 8,
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: WelcomeScreen(),
    ),
  );
}
